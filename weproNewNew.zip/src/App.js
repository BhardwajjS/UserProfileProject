import logo from './logo.svg';
import Dashboard from './Pages/Dashboard/dashbord';
function App() {
  return (
    <div className="App">
     <Dashboard/>
    </div>
  );
}

export default App;
