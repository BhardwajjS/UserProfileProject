export const APIURL = "https://dummyapi.io/data/v1/user"
export const feeForSpot = 0.002